package com.denis.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        savedInstanceState.containsKey("param1");
//        int num = savedInstanceState.getInt("param1");
        if(savedInstanceState == null){
//           showFragment(FirstFragment.class);
        }

    }


    public void showFirstFragment(){showFragment(FirstFragment.class);}
    public void showThirdFragment(){showFragment(ThirdFragment.class);}
    public void showSecondFragment(){
        showFragment(SecondFragment.class);
    }

    private void showFragment(@NonNull Class<? extends Fragment> fragmentClass) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_view, fragmentClass, null)
                .addToBackStack(null)
                .commit();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("param1", 10);
    }
}